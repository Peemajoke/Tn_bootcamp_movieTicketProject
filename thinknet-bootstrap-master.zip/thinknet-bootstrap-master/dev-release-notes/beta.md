# version: {x.x.x}
#### Team: {Team Name}
#### Type: {Feature, Bug}
- Changing Detail | [Task](Jira Url) | [Merge-Request](GitLab Url)