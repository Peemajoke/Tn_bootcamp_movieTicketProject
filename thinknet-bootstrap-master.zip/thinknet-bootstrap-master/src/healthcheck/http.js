const isReady = () => Promise.resolve(true)

const isAlive = () => Promise.resolve(true)

export default {
  isReady,
  isAlive,
}
