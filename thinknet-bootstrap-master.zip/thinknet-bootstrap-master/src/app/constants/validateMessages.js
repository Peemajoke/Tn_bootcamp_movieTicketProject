const MESSAGE = {
  isDate: 'must be date.',
  isInt: 'must be only numeric.',
  isArray: 'must be only array.',
  isString: 'must be only string.',
  notEmpty: 'is required.',
}

export default MESSAGE
