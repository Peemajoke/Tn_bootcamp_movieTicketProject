module.exports = {
  verbose: true,
  testEnvironment: 'node',
  setupFilesAfterEnv: ['./jest.setup.js'],
  resetMocks: true,
}
